# AI Video Platform

## Steps to run the project
1. Install frontend dependencies
2. Run backend API
3. Configure environment variables
4. Start both frontend and backend
